/* ctxmenu.c - SwirlOS right-click context menu for the NetSurf fb frontend.
 *
 * Built from stock fbtk widgets: a full-window invisible "backdrop" that
 * swallows clicks (click outside = dismiss) and a bordered panel holding one
 * text button per entry. Entries depend on what is under the pointer:
 *
 *   image : Save image / Copy image address
 *   link  : Open link  / Copy link address
 *   always: Back / Forward / Reload (only the ones that are available)
 *
 * Widgets are never destroyed from inside their own click callback; closing
 * is deferred through the frontend scheduler. */
#include <limits.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include <libnsfb.h>
#include <libnsfb_event.h>

#include "utils/utils.h"
#include "utils/errors.h"
#include "utils/nsurl.h"
#include "netsurf/browser_window.h"
#include "netsurf/content.h"
#include "netsurf/content_type.h"
#include "netsurf/clipboard.h"
#include "content/hlcache.h"
#include "desktop/browser_history.h"

#include "framebuffer/gui.h"
#include "framebuffer/fbtk.h"
#include "framebuffer/schedule.h"
#include "framebuffer/clipboard.h"

extern bool swirl_save_image_at(struct browser_window *bw, int x, int y);

#define MENU_W      208
#define ITEM_H      26
#define BORDER      1
#define MENU_BG     0xff555555      /* shows through as the border     */
#define ITEM_BG     0xfff2f2f2
#define ITEM_FG     0xff000000
#define URL_MAX     4096

enum act {
        ACT_SAVE_IMG, ACT_COPY_IMG, ACT_OPEN_LINK, ACT_COPY_LINK,
        ACT_BACK, ACT_FORWARD, ACT_RELOAD
};

struct item {
        const char *label;
        enum act act;
};

static struct {
        struct gui_window *gw;
        fbtk_widget_t *backdrop;
        fbtk_widget_t *panel;
        struct item items[8];
        int n_items;
        int cx, cy;             /* content coords of the click        */
        char *link_url;
        char *img_url;
} m;

static bool gw_alive(struct gui_window *gw)
{
        for (struct gui_window *w = window_list; w; w = w->next)
                if (w == gw) return true;
        return false;
}

/* tear down immediately - only call from outside the menu's own callbacks */
static void menu_destroy_now(void)
{
        if (m.panel || m.backdrop) {
                if (m.gw && gw_alive(m.gw)) {
                        if (m.panel) fbtk_set_mapping(m.panel, false);
                        if (m.backdrop) fbtk_set_mapping(m.backdrop, false);
                        if (m.panel) fbtk_destroy_widget(m.panel);
                        if (m.backdrop) fbtk_destroy_widget(m.backdrop);
                        fbtk_request_redraw(m.gw->window);
                }
        }
        free(m.link_url);
        free(m.img_url);
        memset(&m, 0, sizeof m);
}

static void menu_close_cb(void *p)
{
        if (p != (void *)m.panel) return;       /* stale: menu was reopened */
        menu_destroy_now();
}

static void clip_set(const char *s)
{
        if (s && framebuffer_clipboard_table && framebuffer_clipboard_table->set)
                framebuffer_clipboard_table->set(s, strlen(s), NULL, 0);
}

static int backdrop_click(fbtk_widget_t *w, fbtk_callback_info *cbi)
{
        (void)w;
        if (cbi->event->type == NSFB_EVENT_KEY_UP && m.panel)
                framebuffer_schedule(1, menu_close_cb, m.panel);
        return 1;                               /* swallow press + release */
}

static int item_click(fbtk_widget_t *w, fbtk_callback_info *cbi)
{
        const struct item *it = cbi->context;
        struct browser_window *bw;
        (void)w;

        if (cbi->event->type != NSFB_EVENT_KEY_UP) return 1;
        if (cbi->event->value.keycode != NSFB_KEY_MOUSE_1) return 1;
        if (!m.panel || !m.gw || !it) return 1;

        bw = m.gw->bw;
        framebuffer_schedule(1, menu_close_cb, m.panel);

        switch (it->act) {
        case ACT_SAVE_IMG:
                swirl_save_image_at(bw, m.cx, m.cy);
                break;
        case ACT_COPY_IMG:
                clip_set(m.img_url);
                break;
        case ACT_COPY_LINK:
                clip_set(m.link_url);
                break;
        case ACT_OPEN_LINK:
                if (m.link_url) {
                        nsurl *u;
                        if (nsurl_create(m.link_url, &u) == NSERROR_OK) {
                                browser_window_navigate(bw, u, NULL,
                                                BW_NAVIGATE_HISTORY,
                                                NULL, NULL, NULL);
                                nsurl_unref(u);
                        }
                }
                break;
        case ACT_BACK:    browser_window_history_back(bw, false); break;
        case ACT_FORWARD: browser_window_history_forward(bw, false); break;
        case ACT_RELOAD:  browser_window_reload(bw, true); break;
        }
        return 1;
}

static void add_item(const char *label, enum act a)
{
        if (m.n_items < (int)(sizeof m.items / sizeof m.items[0])) {
                m.items[m.n_items].label = label;
                m.items[m.n_items].act = a;
                m.n_items++;
        }
}

/* Open the menu for a right-click.
 *   widget/wx/wy : the browser widget and the click position inside it
 *   cx/cy        : the same point in content (scrolled) coordinates */
void fb_ctxmenu_open(struct gui_window *gw, fbtk_widget_t *widget,
                     int wx, int wy, int cx, int cy)
{
        struct browser_window_features f;
        fbtk_widget_t *parent = gw->window;
        int W, H, px, py, h, i;

        menu_destroy_now();
        m.gw = gw;
        m.cx = cx;
        m.cy = cy;

        memset(&f, 0, sizeof f);
        browser_window_get_features(gw->bw, cx, cy, &f);

        if (f.object && content_get_type(f.object) == CONTENT_IMAGE) {
                nsurl *iu = hlcache_handle_get_url(f.object);
                add_item("Save image", ACT_SAVE_IMG);
                if (iu && strlen(nsurl_access(iu)) < URL_MAX) {
                        m.img_url = strdup(nsurl_access(iu));
                        if (m.img_url) add_item("Copy image address", ACT_COPY_IMG);
                }
        }
        if (f.link && strlen(nsurl_access(f.link)) < URL_MAX) {
                m.link_url = strdup(nsurl_access(f.link));
                if (m.link_url) {
                        add_item("Open link", ACT_OPEN_LINK);
                        add_item("Copy link address", ACT_COPY_LINK);
                }
        }
        if (browser_window_history_back_available(gw->bw))
                add_item("Back", ACT_BACK);
        if (browser_window_history_forward_available(gw->bw))
                add_item("Forward", ACT_FORWARD);
        add_item("Reload", ACT_RELOAD);

        W = fbtk_get_width(parent);
        H = fbtk_get_height(parent);
        h = m.n_items * ITEM_H + 2 * BORDER;

        /* click point in the parent window's coordinates, kept on-screen */
        px = fbtk_get_absx(widget) + wx - fbtk_get_absx(parent);
        py = fbtk_get_absy(widget) + wy - fbtk_get_absy(parent);
        if (px + MENU_W > W) px = W - MENU_W;
        if (py + h > H) py = H - h;
        if (px < 0) px = 0;
        if (py < 0) py = 0;

        m.backdrop = fbtk_create_user(parent, 0, 0, W, H, NULL);
        if (!m.backdrop) { menu_destroy_now(); return; }
        fbtk_set_handler(m.backdrop, FBTK_CBT_CLICK, backdrop_click, NULL);
        fbtk_set_zorder(m.backdrop, INT_MIN);

        m.panel = fbtk_create_window(parent, px, py, MENU_W, h, MENU_BG);
        if (!m.panel) { menu_destroy_now(); return; }
        fbtk_set_zorder(m.panel, INT_MIN);      /* above the backdrop */

        for (i = 0; i < m.n_items; i++) {
                fbtk_widget_t *b = fbtk_create_text_button(m.panel,
                                BORDER, BORDER + i * ITEM_H,
                                MENU_W - 2 * BORDER, ITEM_H,
                                ITEM_BG, ITEM_FG, item_click, &m.items[i]);
                if (b) fbtk_set_text(b, m.items[i].label);
        }
        fbtk_request_redraw(parent);
}
