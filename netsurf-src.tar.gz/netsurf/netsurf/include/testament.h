/* testament.h — SwirlOS port build provenance (replaces the git-testament
 * generated file; the NetSurf sources build UNMODIFIED against this). */
#ifndef NETSURF_TESTAMENT_H
#define NETSURF_TESTAMENT_H

#define USERNAME "swirl"
#define GECOS    "SwirlOS build"
#define WT_ROOT  "/SwirlOS/user/netsurf"
#define WT_HOSTNAME "swirlbox"
#define WT_COMPILEDATE "22.09.2026"
#define WT_BRANCHPATH "netsurf/3.11-port"
#define WT_BRANCHISTRUNK 1
#define WT_REVID "3.11"
#define WT_MODIFIED 0
#define WT_MODIFICATIONS { { 0, 0, 0, 0, 0, 0, 0 } }

#endif
